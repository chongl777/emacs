# Northcode theme

	My emacs theme.
	Dark theme based on blue and orange colors.
	
# Preview images

## Small

![Abbrevs texinfo](prev-small.png)

## Emacs Lisp

![Emacs Lisp](prev-elisp.png)

## Rust

![Rust](prev-rust.png)

## Python

![Python](prev-python.png)
