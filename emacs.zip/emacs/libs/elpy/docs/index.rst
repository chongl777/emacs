Elpy
====

Elpy is the Emacs Python Development Environment. It aims to provide
an easy to install, fully-featured environment for Python development.

Contents:

.. toctree::
   :maxdepth: 2

   introduction
   concepts
   editing
   ide
   extending


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
