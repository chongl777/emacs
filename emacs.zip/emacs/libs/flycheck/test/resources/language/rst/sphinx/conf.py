# -*- coding: utf-8 -*-

# Simple dummy Sphinx configuration

source_suffix = '.rst'
master_doc = 'index'

# General information about the project.
project = u'rst-sphinx'
copyright = u'2014, Foo'
version = '0'
release = '0'
