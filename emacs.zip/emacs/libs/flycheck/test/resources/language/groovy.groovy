class Foo {
    def foo( {}
}
